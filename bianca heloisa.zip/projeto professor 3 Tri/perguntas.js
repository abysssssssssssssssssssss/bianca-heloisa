criaCartao(
    'Programação',
    'O que é Python?',
    'O Python é uma linguagem de Programação'
)

criaCartao(
    'Geografia',
    'Qual a capital da França?',
    'A capital da França é Paris'
)

criaCartao(
    'Programação',
    'O que é uma função?',
    'Uma função é um bloco de códigos que executa uma tarefa'
)

criaCartao(
    'Lingua inglesa',
    'Como diz oi em Inglês', 
    'Oi em Inglês é Hi(RAI)'

)



